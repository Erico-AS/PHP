<?php
    class Mago extends Personagem {

        public function __construct($nickname) {
            parent::__construct("Mago", "personagem-04.png", $nickname, 1, 0, 0);
        }

    }
?>

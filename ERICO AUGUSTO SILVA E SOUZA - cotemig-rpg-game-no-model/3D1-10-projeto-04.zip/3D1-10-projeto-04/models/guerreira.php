<?php
    class Guerreira extends Personagem {

        public function __construct($nickname) {
            parent::__construct("Guerreira", "personagem-06.png", $nickname, 1, 0, 0);
        }

    }
?>

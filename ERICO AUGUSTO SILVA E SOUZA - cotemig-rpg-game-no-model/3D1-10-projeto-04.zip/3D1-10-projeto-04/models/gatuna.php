<?php
    class Gatuna extends Personagem {

        public function __construct($nickname) {
            parent::__construct("Gatuna", "personagem-07.png", $nickname, 1, 0, 0);
        }

    }
?>
